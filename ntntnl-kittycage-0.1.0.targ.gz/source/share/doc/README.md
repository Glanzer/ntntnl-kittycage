R.I.C.E. -l :: Retro Intentional Computing Environment for Linux

This is a set of configurations and tools to make the default computing experience on Arch (and presumably other linux distros) more "Intentional"
